function changeText() {
	document.getElementById("p").innerHTML = "Meg Ryan";
}
